public class Goblin extends Humanoid{

    public Goblin() {
    }

    public Goblin(int health, int xCord, int yCord) {
        super(health, xCord, yCord);
        displayChar = 'G';
    }


}
