public class BattleHandler {

    private Human human;
    private Goblin goblin;

}
